// import NotFound from "./pages/NotFound";

export const routes={
    home:'/',
    contact:'/contacto',
    favs:'/favs',
    // detail:'/dentist/:id'
}