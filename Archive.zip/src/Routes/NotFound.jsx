import React from 'react'

const NotFound = () => {
  return (
    <>
      Page Not Found
    </>
  )
}

export default NotFound