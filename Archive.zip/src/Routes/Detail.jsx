import { useParams } from 'react-router-dom'
import { useEffect } from 'react'
import axios from 'axios'
import { useState } from 'react';
// import { useEstadosGlobales } from './utils/global.context';

//Este componente debera ser estilado como "dark" o "light" dependiendo del theme del Context

const Detail = () => {
  // const { data, theme, setTheme, handleTheme} = useEstadosGlobales()
  
  const {id} = useParams()

  const [data, setData] = useState([])
  const url = `https://jsonplaceholder.typicode.com/users/${id}`
  
  useEffect(() => {
    axios(url)
    .then(res => setData([res.data]))
  
  }, [])
 



  return (
    <>
      <h1>Detail Dentist {id}</h1>
      <table>
          <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Website</th>
          </tr>
          </thead>
          <tbody>
          {data.map((item) => (
            <tr key={item.id}>
              <td>{item.name}</td>
              <td>{item.email}</td>
              <td>{item.phone}</td>
              <td>{item.website}</td>
            </tr>
          ))}
        </tbody>
          </table>
  
      {/* Deberan mostrar el name - email - phone - website por cada user en especifico */}
    </>
  )
}

export default Detail

