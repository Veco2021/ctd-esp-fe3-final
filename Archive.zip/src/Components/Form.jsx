import React from "react";
import { useState } from "react";

//para visaulizar escribir de ruta /dentist/id porq aun no esta hecho dinamico

const Form = ({name, email, website, phone}) => {
  //Aqui deberan implementar el form completo con sus validaciones
  const [input, setInput] = useState({
    name: "",
    email: "",
    phone: "",
    website: "",
  });

  const handleInput = (e) => {
    e.preventDefault();
    setInput({ ...input, [e.target.name]: e.target.value });
    //toDo: validar
  };
  const onSubmit = (e) => {
    e.preventDefault();
    //toDo 'Gracias, te contactaremos lo antes posible'
  };

  
  return (
    <div>
        <form>
          <label>Name</label>
          <input
            type="text"
            name={name}
            // onChange={handleInput}
          />
          <label>Email</label>
          <input
            type="text"
            name={email}
            // onChange={handleInput}
          />
        </form>
       
    </div>
  );
};

export default Form;
