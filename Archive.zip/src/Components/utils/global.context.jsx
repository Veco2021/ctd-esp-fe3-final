import { createContext, useContext, useEffect, useState, useReducer } from "react";
import axios from "axios";

export const initialState = {theme: " ", data: []}
export const ContextGlobal = createContext();



const favsReducer = (state, action) => {
  switch(action.type){
      case 'ADD_FAV':
          return [...state, action.payload]
  }
}

//initialState.theme

// const [data, setData] = useState([])
// const [loading, setLoading] = useState(true)
// const [state, dispatch] = useReducer(reducer, initialState)



export const ContextProvider = ({ children }) => {

const [data, setData] = useState([])
const url = 'https://jsonplaceholder.typicode.com/users'
  
  useEffect(() => {
    axios(url)
    .then(res => setData(res.data))
  
  }, [])


const [stateFavs, dispatchFavs] = useReducer(favsReducer, initialState.data, initFav)

function initFav(initialValue) {
  return localStorage.getItem("favs")
   ?JSON.parse(localStorage.getItem("favs"))
   :initialValue;
}

useEffect(() => {
  localStorage.setItem('favs', JSON.stringify(stateFavs))
}, [stateFavs])

  return (
    <ContextGlobal.Provider value={{
      data,
      setData,
      stateFavs,
      dispatchFavs,
      
      // theme,
      // setTheme,
      // handleChangeTheme
    }}>
      {children}
    </ContextGlobal.Provider>
  );

};

export default ContextProvider;

export const useEstadosGlobales = () => {
  return useContext(ContextGlobal)
}