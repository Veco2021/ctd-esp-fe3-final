import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import { useEstadosGlobales } from "./utils/global.context";



const Card = ({ id, name, username }) => {

  const { dispatchFavs } = useEstadosGlobales();

  const addFav = ()=>{
    dispatchFavs({type: 'ADD_FAV', payload: { id, name, username }})
    // Aqui iria la logica para agregar la Card en el localStorage
  }


 
  return (
    <div className="card">
       <Link key={id} to={`/dentist/${id}`}>
        <img src="/images/doctor.jpg" alt="dentist" />
        <h3>{name}</h3>
        <h4>{username}</h4>
      </Link>
       
        {/* No debes olvidar que la Card a su vez servira como Link hacia la pagina de detalle */}

        {/* Ademas deberan integrar la logica para guardar cada Card en el localStorage */}
        <button onClick={addFav} className="favButton">Add fav</button>
    </div>
  );
};

export default Card;
