import Footer from "./Components/Footer";
import Navbar from "./Components/Navbar";
import {routes} from './Routes';
import {Routes, Route} from 'react-router-dom';
import Home from "./Routes/Home";
import Favs from "./Routes/Favs";
import Contact from "./Routes/Contact";
import Detail from "./Routes/Detail";
import NotFound from "./Routes/NotFound";


function App() {


  return (
      <>
      <Navbar/>
      <Routes>
          <Route path={routes.home} element={<Home/>}/>
          <Route path='/dentist/:id' element={<Detail/>}/>
          <Route path='/favs' element={<Favs/>}/>
          <Route path={routes.contact} element={<Contact/>}/>
          <Route path='*' element={<NotFound/>}/>  
      </Routes>
      <Footer/>
      </>
  );
}

export default App;
